<?php include 'menuLateral.php'; ?>
<!--Hay que ponerle lo del padding y margin pata que no 
escriba debajo del menu-->
<div style="margin-left:210px; padding:15px;">
    <h2>Contenido de la paguina</h2>
</div>
