<?php include 'menu.php'; ?>
<?php
    if ($_SERVER["REQUEST_METHOD"] == "POST"){
        $target_dir = "images/";
        $uploadOK = 1;
        $target_file = $target_dir . basename ($_FILES["archivo"]["name"]);
        $estension = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
        if($estension!="jpg" && $estension!="gif" && $estension!="png" && $estension!="jpeg"){
            $uploadOK = 0;
        }
    }
    function ($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }
?>
<!--Hay que ponerle lo del padding y margin pata que no 
escriba debajo del menu-->
<div style="margin-left:210px; padding:15px;">
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post" enctype="multipart/form-data">
    Select image to upload:
    <input type="file" name="archivo" id="archivo">
    <input type="submit" value="Upload Image" name="submit">
</form>
    <?php echo "$estension";
    ?>
</div>
