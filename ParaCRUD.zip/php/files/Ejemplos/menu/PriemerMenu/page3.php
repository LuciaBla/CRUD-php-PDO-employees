<html>
<body>

<div class="menu">
<?php include 'topMenu.php';?>
</div>

<h1>Welcome to my home Page 3</h1>
<p>Hello</p>

</body>
</html>