<!DOCTYPE html>
<html>
<body>
<?php
    $base=12.3;
    $altura=15.3;
    $area=($base*$altura)/2;
    echo "El area de un triángulo de altura $altura y de $base es de $area";
?>
</body>
</html>