<!DOCTYPE html>
<html>
<body>

<?php
$nombre="Lucía";
$edad=19;
echo "Mi nombre es $nombre y mi edad es $edad";
?> 

</body>
</html>