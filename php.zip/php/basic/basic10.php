<!DOCTYPE html>
<html>
<body>
<?php
    echo "$_SERVER[REMOTE_ADDR] --- $_SERVER[HTTP_USER_AGENT]";
?>
</body>
</html>