<!DOCTYPE html>
<html>
    <body>
    <?php include 'menu.php'; ?>
        <div style="margin-left:210px; padding:15px;">
            <p>Name: Lucía Blanco Gómez</p>
        </div>
    </body>
</html>