<!DOCTYPE html>
<html>
<head>
    <title>Basic 01</title>
</head>
<body>

<h1>Cuestionario Personal</h1>
<p>Nombre :
    <?php
    $nombre="Lucia";
    echo($nombre);
    ?>
</p>
<p>Edad :
    <?php
    $edad=19;
    echo($edad);
    ?>
</p>
<p>Ciudad/Pueblo :
    <?php
    $ciudad="City";
    echo($ciudad);
    ?>
</p>

</body>
</html>