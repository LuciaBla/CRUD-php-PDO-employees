<!DOCTYPE html>
<html>
<body>

<?php  
for ($x = 0; $x <= 100; $x+=10) {
  echo "The number is: $x <br>";
}
?>  
</body>
</html>