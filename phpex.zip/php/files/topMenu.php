<?php
echo '<a href="exampleTop.php">Home</a><br>
<a href="page1.php">Page1</a><br>
<a href="page2.php">Page2</a><br>
<a href="page3.php">Page3</a>';
?>