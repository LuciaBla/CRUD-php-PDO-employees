<form method="GET" action="dataTeam.php">  
  Equipo: 
  <select name="team">
    <option name="team" value="nekoma">Nekoma</option>
    <option name="team" value="karasuno">Karasuno</option>
    <option name="team" value="fukurodani">Fukurodani</option>
    <option name="team" value="aobaJoshai">Aoba Joshai</option>
    <option name="team" value="shiratorizawa">Shiratorizawa</option>
  </select>
  <input type="submit" name="submit" value="Submit">  
</form>